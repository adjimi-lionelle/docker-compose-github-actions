import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      $: 'jquery',
      jquery: 'jquery',
      jQuery: 'jquery',
      bootstrap: 'bootstrap',
      'window.jQuery': 'jquery'
    },
  },
  optimizeDeps: {
    include: ['jquery', 'bootstrap'],
  },
  server: {
    mimeTypes: {
      "js": "application/javascript",
      "ts": "application/typescript"
    }
  }
});